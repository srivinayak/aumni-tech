from django.contrib.auth.models import User, Group
from django_filters import NumberFilter

from .models import Ships as Ships
from rest_framework import serializers
import django_filters


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ['url', 'username', 'email', 'groups']


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ['url', 'name']


class IMOSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Ships
        fields = ['imo', 'ltimestamp', 'llatitude', 'llongitude']
        # fields = ('__all__')


class IMOFilter(django_filters.FilterSet):
    # name = django_filters.CharFilter(lookup_expr='imo')
    name = django_filters.NumberFilter(lookup_expr=9595321)

    class Meta:
        model = Ships
        fields = ['imo', 'ltimestamp', 'llatitude', 'llongitude']


class F(django_filters.FilterSet):
    username = NumberFilter(method='my_custom_filter')

    class Meta:
        model = User
        fields = ['username']

    def my_custom_filter(self, queryset, name, value):
        return queryset.filter(**{
            name: value,
        })
