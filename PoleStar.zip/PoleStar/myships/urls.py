from django.urls import path, include
from django.contrib import admin
from rest_framework import routers
from . import views
from .views import *

router = routers.DefaultRouter()

router.register(r'Ships', ShipsViewSet)

urlpatterns = [
    # path("", views.index, name="index"),
    # path("admin/", admin.site.urls),
    # path("", include("myships.urls")),
    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls')),
    # path('api-auth', include('rest_framework.urls')),
    # path('?imo', include('rest_framework.urls')),
    path('list/', ShipsViewSet.ships_list, name="imo"),
]
