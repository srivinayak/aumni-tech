from django.db import models


# Create your models here.
class Ships(models.Model):
    # id=models.IntegerField(primary_key=True)
    # id=models.IntegerField(primary_key=True)
    imo=models.IntegerField(default=0)
    ltimestamp=models.DateTimeField("Date (with time)")
    llatitude=models.CharField(max_length=21)
    llongitude=models.CharField(max_length=21)

