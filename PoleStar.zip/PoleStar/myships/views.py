import rest_framework.response
from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpRequest

from django.contrib.auth.models import User, Group
from rest_framework import viewsets, filters
from rest_framework import permissions
from rest_framework.views import APIView

from .models import Ships
from .serializers import UserSerializer, GroupSerializer, IMOSerializer, IMOFilter


# Create your views here.

def index(request):
    return HttpResponse("Welcome to International Maritime Organization")


def check_imo(request, imo_exists):
    my_GET_Data = request.query_params
    if my_GET_Data == "imo":
        return HttpResponse(content="200 OK")
    else:
        return HttpResponse(content="400 Bad Request")


class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]


class GroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    permission_classes = [permissions.IsAuthenticated]


class ShipsViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Ships.objects.all()
    # if HttpRequest.query_params["imo"]:
    # queryset = Ships.imo
    serializer_class = IMOSerializer
    permission_classes = [permissions.AllowAny]
    filter_backends = (filters.OrderingFilter,)
    ordering_fields = ('imo',)
    # filter_obj=IMOSerializer.Meta.fields[0]

    # myqueryset = [queryset.complex_filter(int(filter_obj.__getitem__(0)))]

    # def get_queryset(self):
    #    #return self.myqueryset
    #    return 777

    # def filter_queryset(self, queryset):
    ##request_data = self.request.POST.get("request_data")
    # my_imo = queryset.filter(0)
    # return my_imo

    """
    def get_queryset(self):
        my_imo = self.request.query_params.fromkeys(0)
        return Ships.objects.filter(imo=my_imo)
    """

    def get(self, request, imo):
        result = Ships.objects.get(imo=imo)
        if imo:
            serializers = IMOSerializer(result)
            print({serializers.data})
            return self.response({serializers.data})
        result = Ships.objects.all()
        serializers = IMOSerializer(result, many=True)
        print({serializers.data})
        return self.response({serializers.data})

    def ships_list(request):
        f = IMOFilter(request.GET, queryset=Ships.objects.all())
        return render(request, 'myships/template.html', {'filter': f})

