import pandas as pd
from sqlalchemy import create_engine, text


mdata = "./data/ships.csv"
ships_df = pd.read_csv(mdata)

new_df = ships_df[["imo", "ltimestamp", "llatitude", "llongitude"]]
print(new_df)
print(new_df.shape)

engine = create_engine('sqlite:///db.sqlite3', echo=True)
conn = engine.connect()

new_df.to_sql('myships_ships', con=engine, if_exists='replace', index_label='id')

s1 = conn.execute(text("select * from 'main'.'myships_ships';"))
print(str(s1.all()))

