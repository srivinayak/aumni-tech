
class ShipData:
    def __init__(self):
        pass

    def check_data(self):
        pass



